#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
PAYLOAD = Path(__file__).resolve().parent


def fail(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def replace_once(relative: str, old: str, new: str) -> None:
    path = ROOT / relative
    if not path.is_file():
        fail(f"missing file: {relative}")
    content = path.read_text(encoding="utf-8")
    count = content.count(old)
    if count != 1:
        fail(f"expected exactly one match in {relative}, found {count}: {old[:100]!r}")
    path.write_text(content.replace(old, new, 1), encoding="utf-8")


def copy_new(source_name: str, relative: str) -> None:
    source = PAYLOAD / source_name
    target = ROOT / relative
    if target.exists():
        fail(f"target already exists: {relative}")
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


# Guard the intended base line. The script does not commit or push anything.
if not (ROOT / "app/build.gradle.kts").is_file():
    fail("run from the Client SSH repository root")

replace_once("app/build.gradle.kts", "        versionCode = 46\n", "        versionCode = 47\n")

copy_new(
    "TerminalSessionLogStore.kt",
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionLogStore.kt",
)
copy_new(
    "TerminalSessionLogStoreTest.kt",
    "app/src/test/java/eu/blackserv/clientssh/terminal/TerminalSessionLogStoreTest.kt",
)

# TerminalSessionBus: expose the private transcript path and stream inbound output before UI truncation/clear.
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '    val statusText: String = "Rozłączono",\n    val output: String = "",\n)',
    '    val statusText: String = "Rozłączono",\n    val output: String = "",\n    val fullLogPath: String? = null,\n)',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '    @Volatile\n    private var writer: ((ByteArray) -> Unit)? = null\n',
    '    @Volatile\n    private var writer: ((ByteArray) -> Unit)? = null\n\n'
    '    @Volatile\n    private var transcriptSink: ((String) -> Unit)? = null\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '    fun begin(profile: HostProfile) {\n        writer = null\n',
    '    fun begin(profile: HostProfile) {\n        writer = null\n        transcriptSink = null\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '                statusText = "Zweryfikuj fingerprint hosta…",\n'
    '                output = (previousOutput + notice).takeLast(MAX_BUFFER_CHARS),\n'
    '            )',
    '                statusText = "Zweryfikuj fingerprint hosta…",\n'
    '                output = (previousOutput + notice).takeLast(MAX_BUFFER_CHARS),\n'
    '                fullLogPath = current.fullLogPath,\n'
    '            )',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '                statusText = status,\n'
    '                output = combined.takeLast(MAX_BUFFER_CHARS),\n'
    '            )',
    '                statusText = status,\n'
    '                output = combined.takeLast(MAX_BUFFER_CHARS),\n'
    '                fullLogPath = current.fullLogPath,\n'
    '            )',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '    fun detachWriter() {\n        writer = null\n    }\n',
    '    fun detachWriter() {\n        writer = null\n    }\n\n'
    '    fun attachTranscriptSink(path: String, sink: (String) -> Unit) {\n'
    '        transcriptSink = sink\n'
    '        _snapshot.update { it.copy(fullLogPath = path) }\n'
    '    }\n\n'
    '    fun detachTranscriptSink() {\n'
    '        transcriptSink = null\n'
    '    }\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/terminal/TerminalSessionBus.kt",
    '    fun append(text: String) {\n        if (text.isEmpty()) return\n        _snapshot.update { current ->',
    '    fun append(text: String) {\n        if (text.isEmpty()) return\n'
    '        runCatching { transcriptSink?.invoke(text) }\n'
    '        _snapshot.update { current ->',
)

# TerminalSessionService: open one private log per logical session, resume it with Session Keeper,
# keep it across reconnects, and close it on final termination.
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    'import eu.blackserv.clientssh.terminal.TerminalSessionBus\n',
    'import eu.blackserv.clientssh.terminal.TerminalSessionBus\n'
    'import eu.blackserv.clientssh.terminal.TerminalSessionLogStore\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    private val appStore by lazy { LocalAppStore(applicationContext) }\n'
    '    private val sessionPrefs by lazy { getSharedPreferences(PREFS_NAME, MODE_PRIVATE) }\n',
    '    private val appStore by lazy { LocalAppStore(applicationContext) }\n'
    '    private val sessionPrefs by lazy { getSharedPreferences(PREFS_NAME, MODE_PRIVATE) }\n'
    '    private val sessionLogStore by lazy {\n'
    '        TerminalSessionLogStore(File(noBackupFilesDir, TerminalSessionLogStore.DIRECTORY_NAME))\n'
    '    }\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '        }\n\n        updateNotification(profile.name, if (restoringSession) "Przywracanie połączenia…" else "Łączenie…", profile.id)\n',
    '        }\n\n'
    '        prepareSessionLog(profile, restoringSession)\n\n'
    '        updateNotification(profile.name, if (restoringSession) "Przywracanie połączenia…" else "Łączenie…", profile.id)\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    override fun onDestroy() {\n'
    '        HostKeyTrustBus.cancelUnknown()\n'
    '        connectionJob?.cancel()\n'
    '        reconnectJob?.cancel()\n'
    '        closeTransport()\n'
    '        serviceScope.cancel()\n\n'
    '        val profile = activeProfile\n',
    '    override fun onDestroy() {\n'
    '        val profile = activeProfile\n'
    '        val preserveLogForRestore = maintainSession && sessionKeeperEnabled && profile != null\n'
    '        if (preserveLogForRestore) {\n'
    '            runCatching {\n'
    '                sessionLogStore.appendNotice(\n'
    '                    "Usługa została zatrzymana przez Androida; log zostanie wznowiony przy Session Keeperze.",\n'
    '                )\n'
    '            }\n'
    '        }\n'
    '        closeSessionLog(preserveForRestore = preserveLogForRestore)\n'
    '        HostKeyTrustBus.cancelUnknown()\n'
    '        connectionJob?.cancel()\n'
    '        reconnectJob?.cancel()\n'
    '        closeTransport()\n'
    '        serviceScope.cancel()\n\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    private fun finishShellSession(profile: HostProfile, message: String) {\n'
    '        maintainSession = false\n',
    '    private fun finishShellSession(profile: HostProfile, message: String) {\n'
    '        runCatching { sessionLogStore.appendNotice(message) }\n'
    '        closeSessionLog(preserveForRestore = false)\n'
    '        maintainSession = false\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    private fun scheduleReconnect(profile: HostProfile, reason: String) {\n'
    '        if (!maintainSession || !sessionKeeperEnabled) return\n',
    '    private fun scheduleReconnect(profile: HostProfile, reason: String) {\n'
    '        if (!maintainSession || !sessionKeeperEnabled) return\n'
    '        runCatching {\n'
    '            sessionLogStore.appendNotice(\n'
    '                "$reason Ponawiam połączenie za ${RECONNECT_DELAY_MS / 1_000} s.",\n'
    '            )\n'
    '        }\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    private fun failPermanently(profile: HostProfile, message: String) {\n'
    '        maintainSession = false\n',
    '    private fun failPermanently(profile: HostProfile, message: String) {\n'
    '        runCatching { sessionLogStore.appendNotice("Sesja zatrzymana: $message") }\n'
    '        closeSessionLog(preserveForRestore = false)\n'
    '        maintainSession = false\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    private fun disconnectAndStop(startId: Int, message: String) {\n'
    '        maintainSession = false\n',
    '    private fun disconnectAndStop(startId: Int, message: String) {\n'
    '        runCatching { sessionLogStore.appendNotice(message) }\n'
    '        closeSessionLog(preserveForRestore = false)\n'
    '        maintainSession = false\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '            .remove(KEY_ACTIVE_PROFILE_ID)\n'
    '            .remove(KEY_SESSION_WAS_CONNECTED)\n'
    '            .apply()\n',
    '            .remove(KEY_ACTIVE_PROFILE_ID)\n'
    '            .remove(KEY_SESSION_WAS_CONNECTED)\n'
    '            .remove(KEY_ACTIVE_LOG_PATH)\n'
    '            .apply()\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '    private fun closeTransport() {\n',
    '    private fun prepareSessionLog(profile: HostProfile, restoringSession: Boolean) {\n'
    '        TerminalSessionBus.detachTranscriptSink()\n'
    '        runCatching { sessionLogStore.close() }\n'
    '        val resumePath = if (restoringSession) {\n'
    '            sessionPrefs.getString(KEY_ACTIVE_LOG_PATH, null)\n'
    '        } else {\n'
    '            null\n'
    '        }\n'
    '        runCatching {\n'
    '            sessionLogStore.open(profile.name, profile.host, profile.port, resumePath)\n'
    '        }.onSuccess { file ->\n'
    '            sessionPrefs.edit().putString(KEY_ACTIVE_LOG_PATH, file.absolutePath).apply()\n'
    '            TerminalSessionBus.attachTranscriptSink(file.absolutePath, sessionLogStore::appendInbound)\n'
    '        }.onFailure {\n'
    '            sessionPrefs.edit().remove(KEY_ACTIVE_LOG_PATH).apply()\n'
    '            TerminalSessionBus.append(\n'
    '                "\\n[Log] Pełny log sesji jest niedostępny; bufor terminala nadal działa.\\n",\n'
    '            )\n'
    '        }\n'
    '    }\n\n'
    '    private fun closeSessionLog(preserveForRestore: Boolean) {\n'
    '        TerminalSessionBus.detachTranscriptSink()\n'
    '        runCatching { sessionLogStore.close() }\n'
    '        if (!preserveForRestore) sessionPrefs.edit().remove(KEY_ACTIVE_LOG_PATH).apply()\n'
    '    }\n\n'
    '    private fun closeTransport() {\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/service/TerminalSessionService.kt",
    '        private const val KEY_SESSION_WAS_CONNECTED = "session_was_connected"\n',
    '        private const val KEY_SESSION_WAS_CONNECTED = "session_was_connected"\n'
    '        private const val KEY_ACTIVE_LOG_PATH = "active_log_path"\n',
)

# Stream export directly from the private file; fallback to the bounded UI buffer if no full log exists.
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    'import eu.blackserv.clientssh.terminal.TerminalSessionBus\n',
    'import eu.blackserv.clientssh.terminal.TerminalSessionBus\n'
    'import eu.blackserv.clientssh.terminal.TerminalSessionLogStore\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    'import kotlinx.coroutines.flow.MutableStateFlow\n',
    'import kotlinx.coroutines.flow.MutableStateFlow\nimport java.io.File\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    'class MainActivity : ComponentActivity() {\n    private var pendingLogContent: String = ""\n',
    'class MainActivity : ComponentActivity() {\n'
    '    private var pendingLogContent: String = ""\n'
    '    private var pendingLogSource: File? = null\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    '    ) { uri ->\n'
    '        if (uri != null) {\n'
    '            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->\n'
    '                writer.write(pendingLogContent)\n'
    '            }\n'
    '        }\n'
    '        pendingLogContent = ""\n'
    '    }\n',
    '    ) { uri ->\n'
    '        if (uri != null) {\n'
    '            contentResolver.openOutputStream(uri)?.use { output ->\n'
    '                val source = pendingLogSource\n'
    '                if (source != null && source.isFile) {\n'
    '                    source.inputStream().buffered().use { input -> input.copyTo(output) }\n'
    '                } else {\n'
    '                    output.write(pendingLogContent.toByteArray(Charsets.UTF_8))\n'
    '                }\n'
    '            }\n'
    '        }\n'
    '        pendingLogSource = null\n'
    '        pendingLogContent = ""\n'
    '    }\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    '                        onSaveLog = { filename, content ->\n'
    '                            pendingLogContent = content\n'
    '                            saveLogLauncher.launch(filename.sanitizeFilename())\n'
    '                        },\n',
    '                        onSaveLog = { filename, sourcePath, fallbackContent ->\n'
    '                            pendingLogSource = TerminalSessionLogStore.resolveForExport(\n'
    '                                File(noBackupFilesDir, TerminalSessionLogStore.DIRECTORY_NAME),\n'
    '                                sourcePath,\n'
    '                            )\n'
    '                            pendingLogContent = if (pendingLogSource == null) fallbackContent else ""\n'
    '                            saveLogLauncher.launch(filename.sanitizeFilename())\n'
    '                        },\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    '    onSaveLog: (String, String) -> Unit,\n',
    '    onSaveLog: (String, String?, String) -> Unit,\n',
)

replace_once(
    "app/src/main/java/eu/blackserv/clientssh/ui/screens/TerminalScreen.kt",
    '    onSaveLog: (String, String) -> Unit,\n',
    '    onSaveLog: (String, String?, String) -> Unit,\n',
)
replace_once(
    "app/src/main/java/eu/blackserv/clientssh/ui/screens/TerminalScreen.kt",
    '                        IconButton(onClick = { onSaveLog("${profile.name}.log", plainOutput) }) {\n'
    '                            Icon(Icons.Default.Save, contentDescription = "Zapisz log")\n'
    '                        }\n',
    '                        IconButton(\n'
    '                            onClick = {\n'
    '                                onSaveLog("${profile.name}.log", session.fullLogPath, plainOutput)\n'
    '                            },\n'
    '                        ) {\n'
    '                            Icon(Icons.Default.Save, contentDescription = "Zapisz pełny log")\n'
    '                        }\n',
)

subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)
print("Full streaming log v47 patch applied. Review git diff, then run unit tests and Android CI.")
