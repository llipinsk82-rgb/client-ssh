#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def write(path: str, content: str) -> None:
    target = ROOT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content.rstrip() + "\n", encoding="utf-8")


def replace(path: str, old: str, new: str, *, count: int | None = None) -> None:
    target = ROOT / path
    text = target.read_text(encoding="utf-8")
    occurrences = text.count(old)
    if occurrences == 0:
        raise SystemExit(f"Expected source not found in {path}: {old[:120]!r}")
    if count is not None and occurrences < count:
        raise SystemExit(f"Expected at least {count} occurrences in {path}, found {occurrences}: {old[:120]!r}")
    updated = text.replace(old, new, count if count is not None else -1)
    target.write_text(updated, encoding="utf-8")


THEME = r'''package eu.blackserv.clientssh.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import eu.blackserv.clientssh.model.AppSkin

private val PremiumNight = Color(0xFF010611)
private val PremiumDeep = Color(0xFF041126)
private val PremiumPanel = Color(0xE6081830)
private val PremiumPanelSoft = Color(0xD9102846)
private val PremiumBlue = Color(0xFF008DFF)
private val PremiumCyan = Color(0xFF26D5FF)
private val PremiumIce = Color(0xFFEAF5FF)
private val PremiumMuted = Color(0xFFA4B9D1)
private val PremiumAmber = Color(0xFFFFB85C)
private val PremiumDanger = Color(0xFFFF7187)

val LocalAppSkin = staticCompositionLocalOf { AppSkin.GRAPHITE }

private val PremiumDarkColors = darkColorScheme(
    primary = PremiumBlue,
    secondary = PremiumAmber,
    tertiary = PremiumCyan,
    background = Color.Transparent,
    surface = PremiumPanel,
    surfaceVariant = PremiumPanelSoft,
    onPrimary = Color(0xFF001526),
    onSecondary = Color(0xFF241504),
    onTertiary = Color(0xFF00161E),
    onBackground = PremiumIce,
    onSurface = PremiumIce,
    onSurfaceVariant = PremiumMuted,
    outline = Color(0xFF24517D),
    outlineVariant = Color(0xFF163656),
    error = PremiumDanger,
    onError = Color(0xFF250007),
)

private val PremiumNeonColors = darkColorScheme(
    primary = PremiumCyan,
    secondary = PremiumAmber,
    tertiary = Color(0xFF3D7CFF),
    background = Color.Transparent,
    surface = Color(0xE606152A),
    surfaceVariant = Color(0xD90B2442),
    onPrimary = Color(0xFF00161E),
    onSecondary = Color(0xFF241504),
    onTertiary = Color.White,
    onBackground = Color(0xFFF1FAFF),
    onSurface = Color(0xFFF1FAFF),
    onSurfaceVariant = Color(0xFFABC5DD),
    outline = Color(0xFF147DB9),
    outlineVariant = Color(0xFF16466D),
    error = PremiumDanger,
    onError = Color(0xFF250007),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0069B8),
    secondary = Color(0xFF8A5B12),
    tertiary = Color(0xFF00677F),
    background = Color(0xFFF3F7FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE4EDF7),
    onPrimary = Color.White,
    onBackground = Color(0xFF07131F),
    onSurface = Color(0xFF07131F),
    onSurfaceVariant = Color(0xFF4E6275),
    outline = Color(0xFFB8C8D8),
)

private val PremiumShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

private val PremiumNeonShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

@Composable
fun ClientSshTheme(
    skin: AppSkin = AppSkin.GRAPHITE,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = when {
        !darkTheme -> LightColors
        skin == AppSkin.NEON -> PremiumNeonColors
        else -> PremiumDarkColors
    }
    val shapes = if (skin == AppSkin.NEON) PremiumNeonShapes else PremiumShapes

    CompositionLocalProvider(LocalAppSkin provides skin) {
        MaterialTheme(
            colorScheme = colors,
            shapes = shapes,
            content = content,
        )
    }
}

@Composable
fun AppBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val skin = LocalAppSkin.current
    val accent = if (skin == AppSkin.NEON) PremiumCyan else PremiumBlue
    val secondaryAccent = if (skin == AppSkin.NEON) Color(0xFF3D7CFF) else PremiumCyan
    val gridStep = with(LocalDensity.current) { 30.dp.toPx() }
    val fineStroke = with(LocalDensity.current) { 0.55.dp.toPx() }
    val curveStroke = with(LocalDensity.current) { 0.9.dp.toPx() }
    val nodeRadius = with(LocalDensity.current) { 2.4.dp.toPx() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(PremiumNight)
                drawRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF061A3B),
                            PremiumDeep,
                            PremiumNight,
                        ),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height),
                    ),
                )
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(accent.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.05f, size.height * 0.22f),
                        radius = size.maxDimension * 0.72f,
                    ),
                )
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(secondaryAccent.copy(alpha = 0.13f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.78f),
                        radius = size.maxDimension * 0.60f,
                    ),
                )

                var x = 0f
                while (x <= size.width) {
                    drawLine(
                        color = PremiumCyan.copy(alpha = 0.035f),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = fineStroke,
                    )
                    x += gridStep
                }
                var y = 0f
                while (y <= size.height) {
                    drawLine(
                        color = PremiumBlue.copy(alpha = 0.032f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = fineStroke,
                    )
                    y += gridStep
                }

                repeat(7) { index ->
                    val shift = index * size.height * 0.034f
                    val leftCurve = Path().apply {
                        moveTo(-size.width * 0.10f, size.height * 0.06f + shift)
                        cubicTo(
                            size.width * 0.18f,
                            size.height * 0.03f + shift,
                            size.width * 0.04f,
                            size.height * 0.38f + shift,
                            size.width * 0.34f,
                            size.height * 0.46f + shift,
                        )
                    }
                    drawPath(
                        path = leftCurve,
                        color = accent.copy(alpha = 0.12f - index * 0.010f),
                        style = Stroke(width = curveStroke),
                    )

                    val rightCurve = Path().apply {
                        moveTo(size.width * 1.08f, size.height * 0.20f + shift)
                        cubicTo(
                            size.width * 0.76f,
                            size.height * 0.18f + shift,
                            size.width * 0.96f,
                            size.height * 0.52f + shift,
                            size.width * 0.62f,
                            size.height * 0.63f + shift,
                        )
                    }
                    drawPath(
                        path = rightCurve,
                        color = secondaryAccent.copy(alpha = 0.10f - index * 0.008f),
                        style = Stroke(width = curveStroke),
                    )
                }

                val nodes = listOf(
                    Offset(size.width * 0.10f, size.height * 0.18f),
                    Offset(size.width * 0.22f, size.height * 0.36f),
                    Offset(size.width * 0.84f, size.height * 0.24f),
                    Offset(size.width * 0.72f, size.height * 0.58f),
                    Offset(size.width * 0.18f, size.height * 0.78f),
                    Offset(size.width * 0.88f, size.height * 0.86f),
                )
                nodes.forEachIndexed { index, node ->
                    val nodeColor = if (index % 2 == 0) accent else secondaryAccent
                    drawCircle(nodeColor.copy(alpha = 0.14f), nodeRadius * 3.8f, node)
                    drawCircle(nodeColor.copy(alpha = 0.85f), nodeRadius, node)
                }

                drawLine(
                    color = accent.copy(alpha = 0.55f),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = curveStroke,
                )
            },
        content = content,
    )
}
'''

STARTUP = r'''package eu.blackserv.clientssh.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

private val SplashNight = Color(0xFF010611)
private val SplashDeep = Color(0xFF04142D)
private val SplashBlue = Color(0xFF008DFF)
private val SplashCyan = Color(0xFF20D5FF)
private val SplashIce = Color(0xFFF3F8FF)

@Composable
fun StartupScreen(
    onFinished: () -> Unit,
) {
    val context = LocalContext.current
    var visible by remember { mutableStateOf(false) }
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 650),
        label = "premium-splash-fade",
    )
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = {},
    )

    LaunchedEffect(Unit) {
        visible = true
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        delay(2_300)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF020919), SplashDeep, SplashNight),
                ),
            )
            .graphicsLayer(alpha = alpha),
    ) {
        PremiumSplashGraphics()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(42.dp))
            BsPremiumMark()
            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Client",
                    color = SplashIce,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.4.sp,
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "SSH",
                    color = SplashCyan,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                )
            }

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .width(210.dp)
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, SplashCyan, Color.Transparent),
                        ),
                    ),
            )
            Spacer(Modifier.height(14.dp))
            Text(
                text = "B E Z P I E C Z N E   P O Ł Ą C Z E N I A.",
                color = SplashIce.copy(alpha = 0.90f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "P E Ł N A   K O N T R O L A.",
                color = SplashCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.weight(1f))
            PremiumDeviceScene()
            Spacer(Modifier.weight(0.35f))

            LinearProgressIndicator(
                modifier = Modifier.width(124.dp).height(2.dp),
                color = SplashCyan,
                trackColor = SplashBlue.copy(alpha = 0.16f),
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = "BLACKSERV SECURE COMMAND DECK",
                color = Color(0xFF8EAAC7),
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.2.sp,
            )
        }
    }
}

@Composable
private fun PremiumSplashGraphics() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(SplashBlue.copy(alpha = 0.24f), Color.Transparent),
                center = androidx.compose.ui.geometry.Offset(size.width * 0.04f, size.height * 0.24f),
                radius = size.maxDimension * 0.70f,
            ),
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(SplashCyan.copy(alpha = 0.13f), Color.Transparent),
                center = androidx.compose.ui.geometry.Offset(size.width * 0.92f, size.height * 0.68f),
                radius = size.maxDimension * 0.50f,
            ),
        )

        val step = size.width / 12f
        var x = 0f
        while (x <= size.width) {
            drawLine(
                SplashBlue.copy(alpha = 0.055f),
                androidx.compose.ui.geometry.Offset(x, size.height * 0.55f),
                androidx.compose.ui.geometry.Offset(x, size.height),
                strokeWidth = 1f,
            )
            x += step
        }
        var y = size.height * 0.58f
        while (y <= size.height) {
            drawLine(
                SplashCyan.copy(alpha = 0.045f),
                androidx.compose.ui.geometry.Offset(0f, y),
                androidx.compose.ui.geometry.Offset(size.width, y),
                strokeWidth = 1f,
            )
            y += step
        }

        repeat(8) { index ->
            val path = Path().apply {
                moveTo(-size.width * 0.12f, size.height * (0.04f + index * 0.018f))
                cubicTo(
                    size.width * 0.25f,
                    size.height * (0.02f + index * 0.020f),
                    size.width * 0.03f,
                    size.height * (0.23f + index * 0.022f),
                    size.width * 0.38f,
                    size.height * (0.30f + index * 0.020f),
                )
            }
            drawPath(
                path,
                SplashBlue.copy(alpha = 0.18f - index * 0.014f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.2f),
            )
        }

        val points = listOf(
            androidx.compose.ui.geometry.Offset(size.width * 0.10f, size.height * 0.37f),
            androidx.compose.ui.geometry.Offset(size.width * 0.84f, size.height * 0.28f),
            androidx.compose.ui.geometry.Offset(size.width * 0.18f, size.height * 0.62f),
            androidx.compose.ui.geometry.Offset(size.width * 0.74f, size.height * 0.72f),
            androidx.compose.ui.geometry.Offset(size.width * 0.91f, size.height * 0.49f),
            androidx.compose.ui.geometry.Offset(size.width * 0.42f, size.height * 0.86f),
        )
        points.forEachIndexed { index, point ->
            val color = if (index % 2 == 0) SplashCyan else SplashBlue
            drawCircle(color.copy(alpha = 0.18f), radius = 11f, center = point)
            drawCircle(color.copy(alpha = 0.90f), radius = 2.4f, center = point)
        }
    }
}

@Composable
private fun BsPremiumMark() {
    Box(
        modifier = Modifier.size(width = 174.dp, height = 150.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "B",
            modifier = Modifier.offset(x = (-14).dp),
            color = SplashIce,
            fontSize = 138.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (-10).sp,
        )
        Text(
            text = "S",
            modifier = Modifier.offset(x = 15.dp, y = 8.dp),
            color = SplashCyan,
            fontSize = 102.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (-7).sp,
        )
    }
}

@Composable
private fun PremiumDeviceScene() {
    Box(
        modifier = Modifier.fillMaxWidth().height(305.dp),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val left = androidx.compose.ui.geometry.Offset(size.width * 0.16f, size.height * 0.72f)
            val center = androidx.compose.ui.geometry.Offset(size.width * 0.50f, size.height * 0.60f)
            val right = androidx.compose.ui.geometry.Offset(size.width * 0.84f, size.height * 0.72f)
            drawLine(SplashCyan.copy(alpha = 0.55f), left, center, strokeWidth = 3f)
            drawLine(SplashBlue.copy(alpha = 0.55f), center, right, strokeWidth = 3f)
            listOf(left, center, right).forEach {
                drawCircle(SplashBlue.copy(alpha = 0.18f), 15f, it)
                drawCircle(SplashCyan, 3.5f, it)
            }
        }

        Surface(
            modifier = Modifier
                .size(width = 178.dp, height = 270.dp)
                .rotate(-12f),
            shape = RoundedCornerShape(34.dp),
            color = Color(0xFF061329),
            shadowElevation = 22.dp,
            border = androidx.compose.foundation.BorderStroke(
                1.4.dp,
                Brush.linearGradient(listOf(SplashCyan, SplashBlue, Color(0xFF234D7D))),
            ),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF0A2446), Color(0xFF030A17)),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    modifier = Modifier
                        .size(104.dp)
                        .background(
                            Brush.radialGradient(
                                listOf(SplashBlue.copy(alpha = 0.38f), Color.Transparent),
                            ),
                            RoundedCornerShape(52.dp),
                        )
                        .border(1.3.dp, SplashCyan.copy(alpha = 0.75f), RoundedCornerShape(52.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Default.Lock,
                        contentDescription = null,
                        tint = SplashIce,
                        modifier = Modifier.size(46.dp),
                    )
                }
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset(x = 8.dp, y = (-28).dp)
                .size(78.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xE60A1B33),
            shadowElevation = 14.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, SplashBlue.copy(alpha = 0.75f)),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = ">_",
                    color = SplashCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = (-8).dp, y = (-24).dp)
                .size(78.dp),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xE60A1B33),
            shadowElevation = 14.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, SplashBlue.copy(alpha = 0.75f)),
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    Icons.Default.Storage,
                    contentDescription = null,
                    tint = SplashCyan,
                    modifier = Modifier.size(36.dp),
                )
            }
        }
    }
}
'''

THEMES_XML = r'''<resources>
    <style name="Theme.ClientSSH" parent="android:style/Theme.Material.NoActionBar">
        <item name="android:fontFamily">sans</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">#010611</item>
        <item name="android:windowBackground">#010611</item>
        <item name="android:colorAccent">#20D5FF</item>
        <item name="android:windowActionModeOverlay">true</item>
    </style>
</resources>
'''

write("app/src/main/java/eu/blackserv/clientssh/ui/theme/Theme.kt", THEME)
write("app/src/main/java/eu/blackserv/clientssh/ui/screens/StartupScreen.kt", STARTUP)
write("app/src/main/res/values/themes.xml", THEMES_XML)

replace(
    "app/src/main/java/eu/blackserv/clientssh/model/Models.kt",
    '''    GRAPHITE(\n        label = "BlackServ Classic",\n        description = "Prosty, spokojny i czytelny wygląd do codziennej pracy.",\n    ),\n    NEON(\n        label = "BlackServ Neon",\n        description = "Ciemniejszy wygląd z mocniejszą zielenią, cyanem i efektem command deck.",\n    ),''',
    '''    GRAPHITE(\n        label = "BlackServ Premium",\n        description = "Pełny graficzny command center: szkło, głębia, sieć i światło w całej aplikacji.",\n    ),\n    NEON(\n        label = "BlackServ Premium Neon",\n        description = "Wysoki kontrast premium z mocniejszym cyanem i kobaltowym światłem.",\n    ),''',
)

# Premium navigation shell on every main screen.
replace(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    '''        containerColor = MaterialTheme.colorScheme.surface.copy(\n            alpha = if (skin == AppSkin.NEON) 0.94f else 1f,\n        ),\n        tonalElevation = if (skin == AppSkin.NEON) 10.dp else 0.dp,''',
    '''        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),\n        tonalElevation = 10.dp,''',
)
replace(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    '''                    selectedIconColor = if (skin == AppSkin.NEON) {\n                        MaterialTheme.colorScheme.tertiary\n                    } else {\n                        MaterialTheme.colorScheme.primary\n                    },''',
    '''                    selectedIconColor = MaterialTheme.colorScheme.tertiary,''',
)
replace(
    "app/src/main/java/eu/blackserv/clientssh/MainActivity.kt",
    '''                    indicatorColor = MaterialTheme.colorScheme.primary.copy(\n                        alpha = if (skin == AppSkin.NEON) 0.20f else 0.12f,\n                    ),''',
    '''                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),''',
)

# Profiles: use the fully composed premium card system for both persisted variants.
replace(
    "app/src/main/java/eu/blackserv/clientssh/ui/screens/ProfilesScreen.kt",
    "    val neon = LocalAppSkin.current == AppSkin.NEON",
    "    val neon = true // Both variants use the complete premium component system.",
)
replace(
    "app/src/main/java/eu/blackserv/clientssh/ui/screens/ProfilesScreen.kt",
    '''                                if (neon) "BLACKSERV NEON // v${BuildConfig.VERSION_NAME}" else "BlackServ Classic • v${BuildConfig.VERSION_NAME}",''',
    '''                                "BLACKSERV PREMIUM // v${BuildConfig.VERSION_NAME}",''',
)
profile_replacements = {
    "Color(0xFF0B1712)": "Color(0xFF07172B)",
    "Color(0xFF1B7246)": "Color(0xFF1B5E9E)",
    "Color(0xFF07100D)": "Color(0xE6081830)",
    "Color(0xFF1E7A4A)": "Color(0xFF087ED1)",
    "Color(0xFFADBAB6)": "Color(0xFFA9BFD8)",
    "Color(0xFF9CB2AA)": "Color(0xFF9DB7D2)",
    "Color(0xFF08170F)": "Color(0xFF00182A)",
    "Color(0xFF160B10)": "Color(0xFF210A14)",
    "Color(0xFF73827C)": "Color(0xFF8198B0)",
    "Color(0xFF091510)": "Color(0xFF091B31)",
    "Color(0xFF091311)": "Color(0xFF091B31)",
    "Color(0xFF58FF94)": "Color(0xFF00B8FF)",
    "Color(0xFF42DFFF)": "Color(0xFF57D7FF)",
    "Color(0xFFFFCB4A)": "Color(0xFFFFB85C)",
}
for old, new in profile_replacements.items():
    replace("app/src/main/java/eu/blackserv/clientssh/ui/screens/ProfilesScreen.kt", old, new)

# Terminal: separate premium command surface, not a flat recolor.
terminal_path = "app/src/main/java/eu/blackserv/clientssh/ui/screens/TerminalScreen.kt"
terminal_replacements = {
    "private val TerminalBackground = Color(0xFF020605)": "private val TerminalBackground = Color(0xFF010611)",
    "private val TerminalPanel = Color(0xFF0B1410)": "private val TerminalPanel = Color(0xE6081830)",
    "private val TerminalButton = Color(0xFF16231B)": "private val TerminalButton = Color(0xFF102A49)",
    "private val TerminalGreen = Color(0xFF62D58A)": "private val TerminalGreen = Color(0xFF20D5FF)",
    "private val TerminalText = Color(0xFFDCE9DF)": "private val TerminalText = Color(0xFFEAF5FF)",
    "contentColor = Color(0xFF031008)": "contentColor = Color(0xFF001522)",
}
for old, new in terminal_replacements.items():
    replace(terminal_path, old, new)
replace(
    terminal_path,
    "import androidx.compose.ui.graphics.Color\n",
    "import androidx.compose.ui.graphics.Brush\nimport androidx.compose.ui.graphics.Color\n",
)
replace(
    terminal_path,
    '''                .background(TerminalBackground)\n                .imePadding(),''',
    '''                .background(\n                    Brush.verticalGradient(\n                        listOf(TerminalBackground, Color(0xFF06172D), TerminalBackground),\n                    ),\n                )\n                .imePadding(),''',
)

# SFTP: premium glass commander with its own depth layer.
sftp_path = "app/src/main/java/eu/blackserv/clientssh/ui/screens/SftpScreen.kt"
sftp_replacements = {
    "private val SftpBackground = Color(0xFF050A08)": "private val SftpBackground = Color(0xFF010611)",
    "private val SftpPanel = Color(0xFF101A16)": "private val SftpPanel = Color(0xE6081830)",
    "private val SftpPanelDeep = Color(0xFF0B120F)": "private val SftpPanelDeep = Color(0xFF061225)",
    "private val SftpRow = Color(0xFF0D1713)": "private val SftpRow = Color(0xE60A1C34)",
    "private val SftpStroke = Color(0xFF2F4339)": "private val SftpStroke = Color(0xFF24517D)",
    "private val SftpHighlight = Color(0xFF526A5C)": "private val SftpHighlight = Color(0xFF2A73BC)",
    "private val SftpAccent = Color(0xFF62D58A)": "private val SftpAccent = Color(0xFF20D5FF)",
    "private val SftpAmber = Color(0xFFD9A441)": "private val SftpAmber = Color(0xFFFFB85C)",
    "private val SftpMuted = Color(0xFFA7B5AD)": "private val SftpMuted = Color(0xFFA4B9D1)",
    "private val SftpDanger = Color(0xFFE88989)": "private val SftpDanger = Color(0xFFFF7187)",
    "containerColor = Color(0xFF07100D)": "containerColor = Color(0xE606152A)",
    "Color(0xFFE6F0EA)": "Color(0xFFEAF5FF)",
}
for old, new in sftp_replacements.items():
    replace(sftp_path, old, new)
replace(
    sftp_path,
    "import androidx.compose.ui.graphics.Color\n",
    "import androidx.compose.ui.graphics.Brush\nimport androidx.compose.ui.graphics.Color\n",
)
replace(
    sftp_path,
    "        containerColor = SftpBackground,",
    "        containerColor = Color.Transparent,",
    count=1,
)
replace(
    sftp_path,
    '''                .background(SftpBackground),''',
    '''                .background(\n                    Brush.verticalGradient(\n                        listOf(SftpBackground, Color(0xFF06172D), SftpBackground),\n                    ),\n                ),''',
    count=1,
)

print("Premium visual skin applied successfully.")
